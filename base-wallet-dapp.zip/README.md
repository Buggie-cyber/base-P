# Base Wallet dApp

A mini frontend-only wallet-connected dApp built for Base.

## Features

- Connect wallet using wagmi and MetaMask
- Configure and target the Base mainnet
- Display connected wallet address
- Show network status and ETH balance on Base
- Prompt users to switch to Base if they are on a different chain

## Setup

```bash
npm install
npm run dev
```

Open the local Vite URL, then use the connect button to sign in with a wallet.

## Notes

- This app uses `wagmi` + `RainbowKit` with a custom Base chain definition.
- The Base RPC endpoint is `https://mainnet.base.org`.
- You can extend this starter with token transfers, contract calls, or NFT views.
