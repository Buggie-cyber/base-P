import { createConfig } from "wagmi";
import { createPublicClient, http } from "viem";
import { metaMask } from "@wagmi/connectors";

export const baseChain = {
  id: 8453,
  name: "Base",
  network: "base",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: {
    default: { http: ["https://mainnet.base.org"] },
    public: { http: ["https://mainnet.base.org"] },
  },
  blockExplorers: {
    default: { name: "Base Explorer", url: "https://base.etherscan.io" },
  },
  testnet: false,
};

const publicClient = createPublicClient({
  chain: baseChain,
  transport: http(baseChain.rpcUrls.default.http[0]),
});

export const wagmiConfig = createConfig(
  {
    autoConnect: true,
    connectors: [(metaMask as any)({ chains: [baseChain] })],
    publicClient,
  } as any
);

