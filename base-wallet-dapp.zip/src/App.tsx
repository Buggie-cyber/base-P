import { useAccount, useBalance, useChainId, useConnect, useDisconnect, useSwitchChain } from "wagmi";

const BASE_CHAIN_ID = 8453;

function App() {
  const { address, isConnected } = useAccount();
  const chainId = useChainId();
  const connectState = useConnect();
  const { disconnect } = useDisconnect();
  const { switchChain } = useSwitchChain();
  const { data: balance, isLoading: balanceLoading, refetch } = useBalance({
    address,
    chainId: BASE_CHAIN_ID,
    query: { enabled: Boolean(address) },
  });

  const isOnBase = chainId === BASE_CHAIN_ID;

  return (
    <div className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">Base Wallet dApp</p>
          <h1>Connect a wallet to Base</h1>
          <p className="description">
            Connect a browser wallet, switch to the Base network, and view your ETH balance.
          </p>
        </div>
      </header>

      <main>
        <section className="card">
          <h2>Wallet status</h2>
          {!isConnected ? (
            <div className="connect-grid">
              {connectState.connectors.map((connector) => (
                <button
                  key={connector.id}
                  className="action-button"
                  disabled={!connector.ready}
                  onClick={() => connectState.connect({ connector })}
                >
                  {connector.name}
                  {!connector.ready ? " (Install wallet)" : ""}
                </button>
              ))}

              {connectState.error && <p className="error">Error: {connectState.error.message}</p>}
            </div>
          ) : (
            <div className="status-grid">
              <div>
                <strong>Address</strong>
                <p>{address}</p>
              </div>
              <div>
                <strong>Network</strong>
                <p>{chainId ?? "Unknown"}</p>
              </div>
              <div>
                <strong>Balance</strong>
                <p>{balanceLoading ? "Loading..." : `${balance?.formatted ?? "0"} ${balance?.symbol ?? "ETH"}`}</p>
              </div>
              <div>
                <strong>Base status</strong>
                <p>{isOnBase ? "On Base ✅" : "Not on Base"}</p>
              </div>
            </div>
          )}

          {isConnected && !isOnBase && switchChain && (
            <button className="action-button" onClick={() => switchChain({ chainId: BASE_CHAIN_ID })}>
              Switch to Base
            </button>
          )}

          {isConnected && (
            <div className="button-row">
              <button className="secondary-button" onClick={() => refetch?.()}>
                Refresh balance
              </button>
              <button className="secondary-button" onClick={() => disconnect()}>
                Disconnect
              </button>
            </div>
          )}
        </section>

        <section className="card highlight">
          <h2>What this app does</h2>
          <ul>
            <li>Connects browser wallets with wagmi</li>
            <li>Targets the Base mainnet</li>
            <li>Displays wallet address and ETH balance</li>
            <li>Prompts a chain switch when needed</li>
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;
